package com.stripe.model;

public class FileUploadCollection extends StripeCollection<FileUpload>{
}
