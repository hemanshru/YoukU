package com.stripe.model;

public class OrderCollection extends StripeCollection<Order> {

}
