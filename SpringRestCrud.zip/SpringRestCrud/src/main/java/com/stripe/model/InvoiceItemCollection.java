package com.stripe.model;

public class InvoiceItemCollection extends StripeCollection<InvoiceItem> {
}
