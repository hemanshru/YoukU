package com.stripe.model;

public class DeletedCard extends DeletedExternalAccount {
}
