package com.stripe.model;

public class DeletedBankAccount extends DeletedExternalAccount {
}
