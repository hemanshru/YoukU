package com.stripe.model;

public class EventCollection extends StripeCollection<Event> {
}
