package com.stripe.model;


public class DeletedBitcoinReceiver extends DeletedExternalAccount {
}
