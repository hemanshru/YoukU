package com.stripe.model;

public class CustomerCollection extends StripeCollection<Customer> {
}
