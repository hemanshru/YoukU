package com.stripe.model;

public interface HasId {
	public String getId();
}
