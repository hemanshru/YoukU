package com.stripe.model;

public class AccountCollection extends StripeCollection<Account> {
}
