package com.stripe.model;

public class OrderReturnCollection extends StripeCollection<Order> {

}
