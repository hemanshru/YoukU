package com.stripe.model;

public class TransferTransactionCollection extends StripeCollection<TransferTransaction> {
}
