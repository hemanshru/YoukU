package com.stripe.model;

public class SKUCollection extends StripeCollection<SKU> {

}
