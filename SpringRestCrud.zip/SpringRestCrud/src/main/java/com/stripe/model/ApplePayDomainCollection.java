package com.stripe.model;

public class ApplePayDomainCollection extends StripeCollection<ApplePayDomain> {
}
