package com.stripe.model;

public class DeletedAlipayAccount extends DeletedExternalAccount {
}
