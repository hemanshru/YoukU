package com.yoku.wallet.controller;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import com.stripe.exception.StripeException;
import com.stripe.model.Charge;
import com.stripe.net.RequestOptions;
import com.stripe.net.RequestOptions.*;
import com.yoku.wallet.model.Status;
import com.yoku.wallet.model.WalletBean;
import com.yoku.wallet.services.WalletServices;

@Controller
@RequestMapping("/wallet")
public class WalletController {

	/**
	 *This methods is called to credit money to wallet. 
	 */
	@Autowired
	WalletServices walletservices;

	@RequestMapping(value = "/addMoney", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody
	Status addWalletAmount(@RequestBody WalletBean walletbean) {
		try {
			walletservices.addWalletAmount(walletbean);
			return new Status(1, "Amount added Successfully to particular Wallet ID  !");
		} catch (Exception e) {
			 e.printStackTrace();
			return new Status(0, e.toString());
		}

	}

	@RequestMapping(value = "/pay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody
	Status payTogateway(@RequestBody Paybean pbean) {
		System.out.println("hiiiiiii");
        RequestOptions requestOptions = (new RequestOptionsBuilder()).setApiKey("sk_test_loqvj7SqfpbcAWw3WFkTJtVA").build();
      //  Map<String, Object> chargeMap = new HashMap<String, Object>();
        Map<String, Object> chargeM = new HashMap<String, Object>();
        chargeM.put("amount",pbean.getAmt());
        chargeM.put("currency", pbean.getCurrency());
       // chargeMap.put("amount", 100);
       // chargeMap.put("currency", "usd");
        Map<String, Object> cardMap = new HashMap<String, Object>();
        //cardMap.put("number", "4242424242424242");
        //cardMap.put("exp_month", 12);
        //cardMap.put("exp_year", 2020);
        cardMap.put("number", pbean.getCardnumber());
        cardMap.put("exp_month", pbean.getMonth());
        cardMap.put("exp_year",pbean.getYear());
        chargeM.put("card", cardMap);
        try {
            Charge charge = Charge.create(chargeM, requestOptions);
            System.out.println(charge);
            return new Status(1, "Amount sent to gateway successfully ! ");
        } catch (StripeException e) {
            e.printStackTrace();
        	return new Status(0, e.toString());
        }
    }
	/**
	 * This method returns total amount present in the wallet
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public @ResponseBody
	double getWalletAmount(@PathVariable("id") long id) {
		WalletBean walletbean = null;
		double	wamount=0.0;
		try {
			walletbean = walletservices.getAmountById(id);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return walletbean.getWalletAmount();
	}

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public @ResponseBody
	List<WalletBean> getWalletList() {

		List<WalletBean> walletList = null;
		try {
			walletList = walletservices.getWalletList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return walletList;
	}

//	@RequestMapping(value = "/listpay", method = RequestMethod.GET)
//	public @ResponseBody
//	List<WalletBean> getWalletListPay() {
//
//		List<WalletBean> walletList = null;
//		try {
//			walletList = walletservices.getWalletList();
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return walletList;
//	}


//	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
//	public @ResponseBody
//	double updatedWalletAmount(@PathVariable("id") long id) {
//		WalletBean walletbean = null;
//		double	wamount=0.0;
//		try {
//			walletbean = walletservices.getAmountById(id);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return walletbean.getWalletAmount();
//	}
//	
}
