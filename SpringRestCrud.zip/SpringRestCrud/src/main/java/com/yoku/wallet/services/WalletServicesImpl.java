package com.yoku.wallet.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.yoku.wallet.dao.WalletDao;
import com.yoku.wallet.helper.WalletHelper;
import com.yoku.wallet.model.WalletBean;


public class WalletServicesImpl implements WalletServices {

	@Autowired
	WalletDao walletDao;
	
	@Autowired
	WalletHelper walletHelper;
	
	
	
	public boolean addWalletAmount(WalletBean walletbean) throws Exception {
	
		WalletBean updatedWalletBean=null;
		updatedWalletBean=walletHelper.updateWalletMoney(walletbean);
		return walletDao.addWalletAmount(updatedWalletBean);
	}

	public WalletBean getAmountById(long id) throws Exception {
		return walletDao.getAmountById(id);
	}

	public List<WalletBean> getWalletList() throws Exception {
		// TODO Auto-generated method stub
		return walletDao.getWalletList();
	}





}
