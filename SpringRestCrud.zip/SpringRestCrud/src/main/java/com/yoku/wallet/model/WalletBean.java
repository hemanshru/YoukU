package com.yoku.wallet.model;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "yoku")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class WalletBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private long id;

	@Column(name = "wallet_amt")
	private double WalletAmount;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public double getWalletAmount() {
		return WalletAmount;
	}

	public void setWalletAmount(double walletAmount) {
		WalletAmount = walletAmount;
	}


}
