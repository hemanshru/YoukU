package com.yoku.wallet.helper;

import org.springframework.beans.factory.annotation.Autowired;

import com.yoku.wallet.model.WalletBean;
import com.yoku.wallet.services.WalletServices;

public class WalletHelper {

	
	@Autowired
	WalletServices walletservices;

	//Method is used to update the wallet amount
	public WalletBean updateWalletMoney(WalletBean walletbean)
	{
	
		WalletBean wbean=null;
		double wamount=0.0;
		long id=walletbean.getId();
		try {
			wbean=walletservices.getAmountById(id);
			wamount=wbean.getWalletAmount();
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return walletbean;
		}
		
		//If wallet amount contains more than 0  
// add the old amount to amount newly added.
		if(wamount>0)
			walletbean.setWalletAmount(walletbean.getWalletAmount()+wamount);
		return walletbean;
		
		
	}
}
