package com.yoku.wallet.services;

import java.util.List;

import com.yoku.wallet.model.WalletBean;


public interface WalletServices {
	public boolean addWalletAmount(WalletBean walletbean) throws Exception;
	public WalletBean getAmountById(long id) throws Exception;
	public List<WalletBean> getWalletList() throws Exception;
	
}

