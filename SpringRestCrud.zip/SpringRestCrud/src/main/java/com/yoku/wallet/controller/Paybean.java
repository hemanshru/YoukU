package com.yoku.wallet.controller;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Paybean implements Serializable {

	private String currency;
	private int month;
	private int amt;
	private String cardnumber;
	private int year;
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getAmt() {
		return amt;
	}
	public void setAmt(int amt) {
		this.amt = amt;
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}

//	public Paybean()
//	{
//		this.amt=900;
//		this.cardnumber="4242424242424242";
//		this.currency="usd";
//		this.year=2020;
//		this.month=12;
//		
//	}

}
