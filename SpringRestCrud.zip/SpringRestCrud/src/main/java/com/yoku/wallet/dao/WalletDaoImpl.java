package com.yoku.wallet.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import com.yoku.wallet.model.WalletBean;

public class WalletDaoImpl implements WalletDao {

	@Autowired
	SessionFactory sessionFactory;

	Session session = null;
	Transaction tx = null;

	public boolean addWalletAmount(WalletBean walletbean) throws Exception {

		session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.update(walletbean);
		tx.commit();
		session.close();
        return false;
	}

	public WalletBean getAmountById(long id) throws Exception {
		session = sessionFactory.openSession();
		WalletBean walletbean = (WalletBean) session.load(WalletBean.class,
				new Long(id));
		tx = session.getTransaction();
		session.beginTransaction();
		tx.commit();		
		return walletbean;
	}

	public List<WalletBean> getWalletList() throws Exception {
		session = sessionFactory.openSession();
		tx = session.beginTransaction();
		@SuppressWarnings("unchecked")
		List<WalletBean> walletList = session.createCriteria(WalletBean.class)
				.list();
		tx.commit();
		session.close();
		return walletList;
	}

}
