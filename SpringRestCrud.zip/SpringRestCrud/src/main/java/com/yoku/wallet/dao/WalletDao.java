package com.yoku.wallet.dao;


import java.util.List;

import com.yoku.wallet.model.WalletBean;


public interface WalletDao {

	public boolean addWalletAmount(WalletBean WalletBean) throws Exception;
	public WalletBean getAmountById(long id) throws Exception;
	public List<WalletBean> getWalletList() throws Exception;

}
